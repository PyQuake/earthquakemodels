import pip

package_name='pymysql'
pip.main(['install', package_name])
